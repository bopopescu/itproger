from django.apps import AppConfig


class SimpyConfig(AppConfig):
    name = 'simpy'
