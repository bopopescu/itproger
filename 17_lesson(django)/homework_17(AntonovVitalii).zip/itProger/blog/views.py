from django.shortcuts import render, get_object_or_404, redirect
from .models import News
from .models import Article
from .models import Contact
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView
)
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.contrib import messages

def home(request):
    data = {
        'news': News.objects.all(),
        'title': "Главная страница блога"
    }
    return render(request, 'blog/home.html', data)


# def contacts(request):
#     return render(request, "blog/contacts.html", {'title': 'Страничка про нас!'})


def practice(request):
    data = {
        "title": 'Практика',
        'hello_text': 'Привет мир',
        'id': 'practice'
    }
    return render(request, "blog/practice.html", data)


def lessons(request):
    data = {
        "title": 'Lessons',
        'hello_text': 'Привет Lessons',
    }
    return render(request, 'blog/lessons.html', data)


def about(request):
    data = {
        "title": 'About',
        'hello_text2': 'Привет About'
    }
    return render(request, 'blog/about.html', data)


class ShowNewsView(ListView):
    model = News
    template_name = 'blog/home.html'
    context_object_name = 'news'
    ordering = ['-date']
    paginate_by = 3

    def get_context_data(self, object_list=None, **kwargs):
        ctx = super(ShowNewsView, self).get_context_data(**kwargs)
        ctx['title'] = 'Главная страница блога'
        return ctx


class NewsDetailView(DetailView):  # blog/news_detail.html
    model = News

    # context_object_name = 'post'

    def get_context_data(self, *, object_list=None, **kwargs):
        ctx = super(NewsDetailView, self).get_context_data(**kwargs)
        ctx['title'] = News.objects.filter(pk=self.kwargs['pk']).first()
        return ctx


class CreateNewsView(LoginRequiredMixin, CreateView):
    model = News

    fields = ['title', 'text']  # , 'date']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


class UpdateNewsView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = News

    fields = ['title', 'text']  # , 'date']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        news = self.get_object()
        if self.request.user == news.author:
            return True
        else:
            return False


class DeleteNewsView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = News
    success_url = '/'

    def test_func(self):
        news = self.get_object()
        if self.request.user == news.author:
            return True
        else:
            return False


class UserAllNewsView(ListView):
    model = News
    template_name = 'blog/user_news.html'
    context_object_name = 'news'
    paginate_by = 3

    def get_queryset(self):
        user = get_object_or_404(User, username=self.kwargs.get('username'))
        return News.objects.filter(author=user).order_by('-date')

    def get_context_data(self, object_list=None, **kwargs):
        ctx = super(UserAllNewsView, self).get_context_data(**kwargs)
        ctx['title'] = f'Все статьи от пользователя {self.kwargs.get("username")}'
        return ctx

#
class ContactsCreateView(CreateView):
    model = Contact
    template_name = 'blog/contacts.html'

    fields = ['letter_theme', 'your_mail', 'letter_text']

    def form_valid(self, form, **kwargs):
        form.save(**kwargs)
        subject = form.instance.letter_theme
        plain_text = form.instance.letter_text
        from_email = form.instance.your_mail
        send_to = 'duk1e.drum@gmail.com'

        send_mail(subject, plain_text, from_email, [send_to])
        messages.success(self.request, f'Сообщение было успешно отправлено от пользователя {form.instance.your_mail}')
        return redirect('blog-contacts')
