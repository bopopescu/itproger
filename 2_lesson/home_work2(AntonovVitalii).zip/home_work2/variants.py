from enum import Enum


class Variants(Enum):
    ROCK = 1
    PAPER = 2
    SCISSORS = 3
